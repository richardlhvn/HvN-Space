AFTERGLOW THEME 0.5.3 — PUBLIC DETAILS / INTERNAL QA

Public pages keep approved About text, readable release facts, article citations,
recording credits and required photo author/license/modification credits.
The older short-description intro, generated review banners, raw Basis paragraphs,
uncertainty lists, research provenance footers and source workflow suffixes are
omitted from public display. Public REST and song RSS also use the reader content.

The original master XLSX and stored WordPress records remain unchanged.
Review flags, unresolved research and noindex settings are retained. Editors can
inspect original notes in Edit artist/song > Internal research and QA.
The ten-artist / 128-song public catalog and current Spotify player are unchanged.

LOCAL UPDATE (existing HvN-Space Windows/WSL Docker project)
1. Extract this ZIP into a temporary folder.
2. Copy its theme folder into your existing HvN-Space folder, merge folders and
   replace matching theme files. Keep .env, plugin, scripts, uploads and volumes.
3. From Ubuntu/WSL inside the existing project folder, run:
   chmod -R a+rX theme
   docker compose restart wordpress
4. Refresh a song page (Ctrl+F5 if needed). No data reimport is required.

The companion Afterglow_Website_QA_Map.xlsx identifies the screenshot fields in
row 92 of the original master and lists internal QA fields for the core 128.
It is a reference map, not a replacement for the owner's working master workbook.

No production deployment or indexing change is included. The separate short-song
preview option remains pending verification of supported playback/source access.
