# Afterglow cleanup helper pack

1. Give the other bot your **latest** `Afterglow_Master_Worksheet.xlsx` separately.
   The full working master is deliberately not bundled here.
2. Attach this helper ZIP (or extract it and attach the files if the bot cannot
   read ZIPs). Copy `PROMPT_CLEANUP.md` into the new chat.
3. Ask for a new cleaned workbook copy, Cleanup Log, Unresolved QA and Launch
   Readiness outputs. Keep your original and later edits.

## Contents

- `PROMPT_CLEANUP.md`: full task and preservation/evidence rules.
- `Afterglow_Website_QA_Map.xlsx`: 19 screenshot mappings and QA fields for 128
  approved selections; it is a reference map, not your editable master.
- `samples/MAKE_US_NEVER_HAPPEN.json`: actual example fields, exact cell locations
  and four source-register entries. These are supplied evidence records, not a
  claim the original articles were newly verified.
- `samples/EXAMPLE_REVIEW.md`: how to investigate a stale-note candidate without
  erasing uncertainties or rewriting approved About copy.
- `samples/CLEAN_PUBLIC_DETAILS.png`: actual cloud screenshot of the prepared
  reader layout, for visual reference only.
- `templates/`: suggested output columns and unresolved/readiness examples.
- `references/`: existing handoff reports. Read current prompt first: older
  version/count/test statements describe earlier phases and cannot establish
  the current owner's local or production state.

Latest prepared display: Core 0.10.1 / Theme 0.5.3. Public scope is ten artists /
128 selections; the full stored catalog is 53 artists / 560 selections / 559
selected pages. Latest packaged updates live on GitHub's
`local-update-2026-11-13` download branch; `main` can be older.

The supplied example comes from a master with SHA-256 `cfbbf90a5b46a2ac7128e54fdf6b58bdc3e8a8500f6653fdca8941975e0424c7`.
If your current master differs, use its current values; do not replace it with
this snapshot. All example values retain their original reference status.

No macros, executable setup scripts, credentials, database backups or full master
workbook are included. No production deployment, workbook import or indexing
change is authorized by using this pack.
