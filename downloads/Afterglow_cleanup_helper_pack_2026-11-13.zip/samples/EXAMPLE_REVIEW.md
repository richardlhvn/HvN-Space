# Worked review example — do not treat this as a verified correction

Record: `shy-martin/make-us-never-happen`.

1. The approved About text is in Review 10 Artists!D92 and Songs Exact!X92.
   Keep it exactly. Its verified review status is an editorial approval.
2. Songs Exact!G92/H92 give 2019-11-08 at day precision. W92 says the earlier
   single day was not established. V92 still includes a year-only claim.
3. Sources row 588 contains shy-martin/src-039, an Apple Music reference whose
   recorded evidence summary says the original single date was 2019-11-08.
4. OPEN AND READ the actual reference and relevant original-release evidence.
   Establish whether the date is the original single or a later edition. A URL
   or a recorded access_status=read does not prove you personally checked it.
5. If supported: reconcile the specific outdated uncertainty/claim and matching
   canonical/review fields in a new workbook copy, preserving old values in
   Cleanup Log. Mark resolved only with the actual evidence you checked.
6. If inaccessible or ambiguous: retain the uncertainty internally. Return the
   exact access problem, existing evidence and next action. Do not manufacture
   a replacement date, source title, quote or a resolved status.

Public outcome: approved About, attribution, source links and a readable release
fact are useful. Raw Basis, uncertainty history, import provenance and the generic
review-pending banner belong to the editor workflow. Theme 0.5.3 already separates
those. Do not erase whole QA columns merely to clean public presentation.

No correction has been pre-approved by this sample, and no original-source check
is claimed. The supplied JSON preserves the original field values for comparison.
