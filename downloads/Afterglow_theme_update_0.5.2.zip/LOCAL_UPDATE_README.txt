AFTERGLOW THEME 0.5.2 — ABOUT THE SONG AS THE INTRODUCTION

This update removes the older short-description paragraph on song pages whenever
About the Song is present. Approved About wording and the existing Spotify player
are unchanged. Songs without About text retain their existing introduction.
The public catalog stays at ten artists / 128 songs.

This package contains only the theme update. No database import is needed when
Core 0.10.1 and the ten-artist catalog are already installed.

LOCAL UPDATE (existing Windows/WSL Docker project)
1. Extract this ZIP to a temporary folder.
2. Copy its theme folder into your existing HvN-Space project folder, merging and
   replacing matching theme files. Keep .env, plugin, scripts, uploads and volumes.
3. From Ubuntu/WSL in your existing project folder, run:
   chmod -R a+rX theme
   docker compose restart wordpress
4. Refresh a song page in your browser (Ctrl+F5 if necessary). About the Song is
   now the main introduction, without the older short-description paragraph.

No reimport, database reset, public indexing change or production deployment is
included. No audio files are included or hosted. A separate 15-second sample
option remains pending verification of supported playback/source access; it is
not included or represented as working in this patch.
