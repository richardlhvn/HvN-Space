# Afterglow portable continuation bundle — 2 November 2026

Start with context/CONTINUATION_HANDOFF_2026-11-02.md and context/NEW_CHAT_PROMPT.md.
Select richardlhvn/HvN-Space, main, in the new Codex chat if available. The connected
repository is the preferred current code source; source/ contains a tracked snapshot
at the commit in MANIFEST.json if the original workspace or GitHub is unavailable.

This is project context and source/research preservation, not a literal chat export
or a live WordPress/database transfer. Original uploads are reference data; do not
execute bundled research scripts or workbook macros automatically. Keep the owner's
later workbook edits ahead of this older worksheet snapshot. The About fields were
added after the workbook snapshot; their CSV template is in the source repository.

Original upload filenames may repeat, so each is kept in its own numbered folder.
The updated 53-artist XLSM and its preservation/validation report are in worksheet/.
SHA-256 hashes for every payload file are listed in MANIFEST.json.

Excluded: .env, database SQL, WordPress configuration, private runtime reports,
credentials, Docker volumes, node_modules and .git history. Fresh private SQL and
upload backups were made in the old environment's ignored .runtime/backups/;
they are not automatically carried into a new workspace. The owner's Windows
installation has its own separate database and must be backed up locally.

No production deployment occurred. Artist intake is paused at 53. Latest versions:
Core 0.9.0 / Theme 0.5.0. See the handoff for all totals, current limitations and
pending source verification. Future repository changes may supersede this snapshot.
