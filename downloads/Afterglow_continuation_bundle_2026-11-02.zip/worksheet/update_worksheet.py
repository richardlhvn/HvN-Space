"""Append catalog records without round-tripping existing Excel package parts."""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import csv
import hashlib
import json
import re
import zipfile
from xml.sax.saxutils import escape
from lxml import etree as ET
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

ROOT = Path('/workspace/HvN-Space')
SOURCE = Path('/workspace/attachments/2559338c-8ab9-4c79-9165-ba1fb009c111/Afterglow worksheet.xlsm')
OUT = Path(__file__).parent
DEST = OUT / 'Afterglow_worksheet_53_artists_2026-10-31.xlsm'
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
ns = {'s': NS}
wb = load_workbook(SOURCE, keep_vba=True)
catalog = json.loads((ROOT / 'plugin/data/research-catalog.json').read_text())
packs = {}
batch_of = {}
for batch in catalog['batches']:
    for slug in batch['slugs']:
        packs[slug] = json.loads((ROOT / f'plugin/data/{slug}.json').read_text())
        batch_of[slug] = batch
existing = {r[0] for r in list(wb['Artists Exact'].values)[1:]}
missing = [slug for slug in packs if slug not in existing]
assert len(packs) == 53 and len(missing) == 23
headers = {s.title: list(next(s.values)) for s in wb}
added = {s: [] for s in headers}

def scalar(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    return value

def append(sheet, record):
    added[sheet].append([scalar(record.get(h)) for h in headers[sheet]])

def urls(pack, ids):
    lookup = {s['id']: s.get('url') for s in pack['sources']}
    return ' | '.join(dict.fromkeys(lookup[i] for i in ids if lookup.get(i))) or None

def claim_ids(record):
    return list(dict.fromkeys(i for c in record.get('supported_claims', []) for i in c.get('source_ids', [])))

def evidence(pack, record):
    return urls(pack, claim_ids(record) + record.get('editorial_notes_source_ids', []) + record.get('artist_statement_source_ids', []))

for slug in missing:
    pack = packs[slug]
    artist = pack['artist']
    append('Artists Exact', artist)
    for source in pack['sources']:
        append('Sources', {'artist_slug': slug, **source})
    image = artist['image']
    append('Media Rights', {
        'artist_slug': slug, 'name': artist['name'],
        **{'image_' + k: v for k, v in image.items()},
        'media_audit_status': 'not_reviewed',
        'media_notes': ['Commercial-editorial reuse permission not established; retain abstract placeholder.'],
    })
    for song in pack['songs']:
        append('Songs Exact', song)
        empty = []
        for field in ['spotify_url', 'release_date', 'short_description', 'genres', 'moods', 'themes']:
            if not song.get(field):
                empty.append(field)
        if not song.get('artist_statement_paraphrase'):
            empty.append('artist_statement_paraphrase (optional; only with attributable evidence)')
        append('Song Review', {
            **song, 'artist_name': artist['name'], 'song_slug': song['slug'],
            'artist_statement_source_urls': urls(pack, song.get('artist_statement_source_ids', [])),
            'editorial_notes_source_urls': urls(pack, song.get('editorial_notes_source_ids', [])),
            'factual_claim_source_urls': urls(pack, claim_ids(song)),
            'missing_or_optional_fields': '; '.join(empty) or None,
            'review_status': 'not_reviewed',
        })

# Preserve all 356 supplied Batch 7 queue rows, then add missing task types.
queue_existing = {
    (r[0], r[2], r[3] or '', r[5])
    for r in list(wb['Research Queue'].values)[1:]
}
with (ROOT / 'docs/research-review/BATCH7_RESEARCH_QUEUE.csv').open(encoding='utf-8-sig', newline='') as f:
    supplied_queue = list(csv.DictReader(f))
for row in supplied_queue:
    key = (row['record_type'], row['artist_slug'], row['song_slug'], row['json_field'])
    assert key not in queue_existing
    append('Research Queue', row)
    queue_existing.add(key)

def task(pack, record, field, priority, why, current=None, note=None):
    artist = pack['artist']
    is_song = record is not artist
    key = ('song' if is_song else 'artist', artist['slug'], record['slug'] if is_song else '', field)
    if key in queue_existing:
        return
    refs = evidence(pack, record)
    if not refs and not is_song:
        refs = ' | '.join(dict.fromkeys(s['url'] for s in pack['sources'] if s.get('url'))) or None
    append('Research Queue', {
        'record_type': key[0], 'artist_name': artist['name'], 'artist_slug': artist['slug'],
        'song_slug': key[2] or None, 'song_title': record.get('title') if is_song else None,
        'json_field': field, 'priority': priority, 'current_value': current,
        'why_needed': why, 'existing_source_urls': refs,
        'researcher_notes': note, 'review_status': 'open',
    })
    queue_existing.add(key)

for slug in missing:
    pack = packs[slug]
    artist = pack['artist']
    for field, priority, why in [
        ('spotify_url', 'high', 'Identify the official Spotify artist profile; distinguish namesakes.'),
        ('official_website', 'medium', 'Find an official artist website or document that none was established.'),
        ('place_of_origin', 'medium', 'Confirm the artist’s origin with a reliable source; do not substitute current residence.'),
        ('full_name', 'low', 'Optional: use a publicly documented professional/legal name; do not infer from usernames.'),
        ('social_profiles', 'low', 'Optional: identify official social accounts through artist/label links; retain platform, URL and source IDs.'),
        ('career_milestones', 'medium', 'Add a few source-backed career milestones with accurate dates and source IDs.'),
    ]:
        if not artist.get(field):
            task(pack, artist, field, priority, why, artist.get(field))
    task(pack, artist, 'biography', 'high',
         'Fact-check this research-starter biography claim by claim, especially current/recent releases and chronology. Existing source access labels are supplied research, not a fresh verification.',
         artist.get('biography'))
    task(pack, artist, 'image', 'low',
         'Only replace the placeholder after documentary permission for commercial-editorial reuse and required attribution are established. Official publication or a Spotify image alone is insufficient.',
         'placeholder')
    for song in pack['songs']:
        if not song.get('spotify_url'):
            task(pack, song, 'spotify_url', 'high',
                 'Find the exact recording-specific Spotify track URL; match title, artist credits and edition. Avoid album/playlist links, covers and different mixes.')
        if not song.get('release_date'):
            task(pack, song, 'release_date', 'medium',
                 'Verify the earliest issue date for this recording and set release_date_precision, release_date_context, release_title and release_type. A later edition is not automatically the original date.')
        if not song.get('artist_statement_paraphrase'):
            task(pack, song, 'artist_statement_paraphrase', 'low',
                 'Optional: find a first-person artist explanation and cite the original interview, timestamp or release statement. Leave null if no reliable statement is found; an editorial reading is not artist intent.')
        if not song.get('short_description') or not song.get('moods') or not song.get('themes'):
            task(pack, song, 'editorial_notes', 'medium',
                 'Write Afterglow’s own clearly labeled listening interpretation, a short_description, and appropriate moods/themes/genres after listening/research. Current starter notes are provisional; do not infer meaning from the title alone.',
                 song.get('editorial_notes'))
        if slug == 'rosie' and song['slug'] == 'little-bit-better':
            task(pack, song, 'spotify_url', 'high',
                 'Shared duet: the site reuses Caleb Hearn’s existing Little Bit Better page. Establish whether ROSIE’s alternate Spotify ID is the same master or a different edition. Do not overwrite the canonical link or create another song page.',
                 song['spotify_url'],
                 'Canonical page key: caleb-hearn/little-bit-better; canonical URL: https://open.spotify.com/track/0GMs3jq70wmCo12pavj4st. Keep both research selections for now.')

def cell_xml(row, col, value, style=2):
    ref = f'{get_column_letter(col)}{row}'
    attrs = f'r="{ref}" s="{style}"'
    if value is None or value == '':
        return f'<c {attrs}/>'
    if isinstance(value, (int, float)):
        return f'<c {attrs} t="n"><v>{value}</v></c>'
    # All supplied/user strings are literal text, never executable formulas.
    value = str(value)
    assert len(value) <= 32767 and not re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', value)
    return f'<c {attrs} t="inlineStr"><is><t xml:space="preserve">{escape(value)}</t></is></c>'

def row_xml(number, values, inputs=(), height=None, style=2):
    attrs = f'r="{number}"'
    if height:
        attrs += f' ht="{height}" customHeight="1"'
    cells = ''.join(cell_xml(number, i, v, 3 if i in inputs else style)
                    for i, v in enumerate(values, 1))
    return f'<row {attrs}>{cells}</row>'

original_parts = {}
with zipfile.ZipFile(SOURCE) as z:
    original_parts = {n: z.read(n) for n in z.namelist()}
parts = dict(original_parts)
changed_parts = []
# Add a wrapped-text style for the new guide; leave every existing style intact.
styles_tree = ET.fromstring(parts['xl/styles.xml'])
cell_xfs = styles_tree.find('s:cellXfs', ns)
guide_style = len(cell_xfs)
wrapped = deepcopy(cell_xfs[2])
wrapped.find('s:alignment', ns).set('wrapText', '1')
cell_xfs.append(wrapped)
cell_xfs.set('count', str(len(cell_xfs)))
parts['xl/styles.xml'] = ET.tostring(styles_tree, encoding='UTF-8', xml_declaration=True, standalone=True)
changed_parts.append('xl/styles.xml')
sheet_paths = {s.title: f'xl/worksheets/sheet{i}.xml' for i, s in enumerate(wb, 1)}
for sheet, rows in added.items():
    if not rows:
        continue
    path = sheet_paths[sheet]
    xml = parts[path].decode('utf-8')
    start = wb[sheet].max_row + 1
    stop = start + len(rows) - 1
    inputs = range(25, 29) if sheet == 'Song Review' else range(11, 16) if sheet == 'Research Queue' else ()
    for number, values in enumerate(rows, start):
        pattern = rf'<row\b(?=[^>]*\br="{number}")[^>]*(?:/>|>.*?</row>)'
        match = re.search(pattern, xml, re.DOTALL)
        new = row_xml(number, values, inputs)
        if match:
            assert '<c ' not in match.group(0), f'Attempted overwrite {sheet} row {number}'
            xml = xml[:match.start()] + new + xml[match.end():]
        else:
            xml = xml.replace('</sheetData>', new + '</sheetData>', 1)
    parts[path] = xml.encode('utf-8')
    changed_parts.append(path)
    table = next(iter(wb[sheet].tables.values()))
    table_path = next(n for n, body in parts.items() if n.startswith('xl/tables/') and f'name="{table.name}"'.encode() in body)
    newref = f'A1:{get_column_letter(wb[sheet].max_column)}{stop}'
    tx = parts[table_path].decode('utf-8').replace(f'ref="{table.ref}"', f'ref="{newref}"')
    if '<autoFilter' not in tx:
        tx = tx.replace('<tableColumns', f'<autoFilter ref="{newref}"/><tableColumns', 1)
    parts[table_path] = tx.encode('utf-8')
    changed_parts.append(table_path)

# A ninth sheet provides instructions and a filterable per-artist coverage view.
artist_rows = list(wb['Artists Exact'].values)[1:] + [tuple(r) for r in added['Artists Exact']]
song_rows = list(wb['Songs Exact'].values)[1:] + [tuple(r) for r in added['Songs Exact']]
queue_rows = list(wb['Research Queue'].values)[1:] + [tuple(r) for r in added['Research Queue']]
media_rows = list(wb['Media Rights'].values)[1:] + [tuple(r) for r in added['Media Rights']]
artists = [dict(zip(headers['Artists Exact'], r)) for r in artist_rows]
songs = [dict(zip(headers['Songs Exact'], r)) for r in song_rows]
media = {r[0]: dict(zip(headers['Media Rights'], r)) for r in media_rows}
task_counts = Counter(r[2] for r in queue_rows if r[-1] == 'open')
review_row = {}
for i, r in enumerate(list(wb['Song Review'].values)[1:] + [tuple(r) for r in added['Song Review']], 2):
    review_row.setdefault(r[5], i)

intro = [
    ['AFTERGLOW — RESEARCH WORKSHEET', 'Updated 31 October 2026'],
    ['Coverage', '53 artists / 530 curated song selections. Added 23 artists and 230 selections from batches 6–7; artist intake remains paused.'],
    ['Start here', 'Research Queue: filter artist_name and priority. Work on high-priority tasks first; fill proposed_value, new_source_url, source_title_or_interview and researcher_notes.'],
    ['Song research', 'Song Review: filter artist_name; use my_new_source_url, my_suggested_text and research_note_for_me. Name each field you propose changing. Keep identifiers unchanged.'],
    ['Review status', 'Use ready_for_review after adding evidence, or no_source_found when you have searched without finding a reliable source. These mark proposals, not automatic publication approval.'],
    ['Facts versus interpretations', 'Artist statements require first-person evidence. Your own listening notes must be labeled Afterglow interpretation. A missing artist statement is optional and may remain blank.'],
    ['Dates and links', 'Match the exact recording and its original/edition context. Unknown dates stay blank; document day/month/year precision. Source IDs are local to each artist, so always include artist_slug.'],
    ['Images', 'Keep abstract placeholders until commercial-editorial permission and attribution are documented. Record permission evidence in Media Rights and Sources.'],
    ['Shared duet', 'ROSIE / Little Bit Better and Caleb Hearn / Little Bit Better are two selections sharing one site page. Keep both worksheet rows; do not create a duplicate page or replace the canonical link without checking the edition.'],
    ['Existing work', 'All original cells in the eight uploaded sheets are preserved. New rows contain supplied research, not newly verified facts. Supplied Sources access_status=read is not a new independent check.'],
    ['Return your research', 'Send this edited workbook back in chat. I will review proposals and sources before syncing the existing site. Editing this workbook does not update WordPress automatically.'],
    ['Overview below', 'Counts describe blank fields in this worksheet, not a full fact-check. Open tasks may include optional fields. Every supplied biography needs verification; newer starter batches are not publication ready.'],
    ['Important distinction', 'The original 30 rows remain your working baseline; they have not been overwritten with site values. The 23 new artist records match the imported research JSON.'],
]
guide_header = ['Artist', 'artist_slug', 'Batch', 'Selections', 'Missing track URLs', 'Missing release dates', 'Missing descriptions', 'Missing statements (optional)', 'Image status', 'Open tasks', 'Song Review first row', 'Artists Exact row', 'Research state']
guide = []
for i, artist in enumerate(artists, 2):
    slug = artist['slug']
    selected = [s for s in songs if s['artist_slug'] == slug]
    m = media[slug]
    image_status = 'Placeholder — permission unresolved' if m['image_use_placeholder'] == 'true' else 'Existing image — see Media Rights'
    guide.append([
        artist['name'], slug, batch_of[slug]['id'], len(selected),
        sum(not s['spotify_url'] for s in selected), sum(not s['release_date'] for s in selected),
        sum(not s['short_description'] for s in selected), sum(not s['artist_statement_paraphrase'] for s in selected),
        image_status, task_counts[slug], review_row[slug], i,
        'Research starter — verify before publication' if slug in missing else 'Original working rows preserved — review pending',
    ])
gx = [f'<worksheet xmlns="{NS}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="15" topLeftCell="A16" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>',
      '<sheetFormatPr defaultRowHeight="30"/><cols><col min="1" max="1" width="29" customWidth="1"/><col min="2" max="2" width="28" customWidth="1"/><col min="3" max="3" width="14" customWidth="1"/><col min="4" max="8" width="19" customWidth="1"/><col min="9" max="9" width="42" customWidth="1"/><col min="10" max="12" width="20" customWidth="1"/><col min="13" max="13" width="57" customWidth="1"/></cols><sheetData>']
for i, values in enumerate(intro, 1):
    gx.append(row_xml(i, values, height=46 if i > 1 else 30, style=guide_style))
gx.append('<row r="15" ht="45" customHeight="1">' + ''.join(cell_xml(15, i, v, 1) for i, v in enumerate(guide_header, 1)) + '</row>')
gx.extend(row_xml(i, values, height=42, style=guide_style) for i, values in enumerate(guide, 16))
gx.append('</sheetData><autoFilter ref="A15:M68"/><mergeCells count="13">' + ''.join(f'<mergeCell ref="B{i}:M{i}"/>' for i in range(1, 14)) + '</mergeCells></worksheet>')
parts['xl/worksheets/sheet9.xml'] = ''.join(gx).encode('utf-8')
wx = parts['xl/workbook.xml'].decode('utf-8').replace('</sheets>', '<sheet state="visible" name="Research Guide" sheetId="9" r:id="rId13"/></sheets>')
parts['xl/workbook.xml'] = wx.encode('utf-8')
rx = parts['xl/_rels/workbook.xml.rels'].decode('utf-8').replace('</Relationships>', f'<Relationship Id="rId13" Type="{REL}/worksheet" Target="worksheets/sheet9.xml"/></Relationships>')
parts['xl/_rels/workbook.xml.rels'] = rx.encode('utf-8')
cx = parts['[Content_Types].xml'].decode('utf-8').replace('</Types>', '<Override ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml" PartName="/xl/worksheets/sheet9.xml"/></Types>')
parts['[Content_Types].xml'] = cx.encode('utf-8')
with zipfile.ZipFile(SOURCE) as source, zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED) as dest:
    for info in source.infolist():
        dest.writestr(info, parts[info.filename])
    dest.writestr('xl/worksheets/sheet9.xml', parts['xl/worksheets/sheet9.xml'])

# Validate package, existing cell/style preservation, all additions and identifiers.
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    for n in z.namelist():
        if n.endswith(('.xml', '.rels')):
            ET.fromstring(z.read(n))
    permitted = set(changed_parts) | {'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', '[Content_Types].xml'}
    for n, body in original_parts.items():
        if n not in permitted:
            assert z.read(n) == body, f'Unexpected package alteration: {n}'
    for name, path in sheet_paths.items():
        old_tree, new_tree = ET.fromstring(original_parts[path]), ET.fromstring(z.read(path))
        old_cells = {c.get('r'): ET.tostring(c) for c in old_tree.findall('.//s:sheetData/s:row/s:c', ns)}
        new_cells = {c.get('r'): ET.tostring(c) for c in new_tree.findall('.//s:sheetData/s:row/s:c', ns)}
        assert all(new_cells.get(ref) == value for ref, value in old_cells.items()), f'Existing cell changed: {name}'

updated = load_workbook(DEST, keep_vba=True)
for s in wb:
    for row in s:
        for cell in row:
            target = updated[s.title][cell.coordinate]
            assert (cell.value, cell._style, cell.data_type) == (target.value, target._style, target.data_type), (s.title, cell.coordinate)
    for idx, values in enumerate(added[s.title], s.max_row + 1):
        actual = [updated[s.title].cell(idx, col).value for col in range(1, len(values) + 1)]
        assert [v or None if isinstance(v, str) else v for v in values] == actual, (s.title, idx)
artist_records = list(updated['Artists Exact'].values)[1:]
song_records = list(updated['Songs Exact'].values)[1:]
assert len(artist_records) == 53 and len({r[0] for r in artist_records}) == 53
assert len(song_records) == 530 and len({(r[2], r[0]) for r in song_records}) == 530
assert set(r[0] for r in artist_records) == set(packs)
assert all(sum(r[2] == slug for r in song_records) == 10 for slug in packs)
for sheet in updated:
    for table in sheet.tables.values():
        assert table.ref.endswith(str(sheet.max_row)), (sheet.title, table.ref, sheet.max_row)
queue_values = list(updated['Research Queue'].values)[1:]
queue_keys = [(r[0], r[2], r[3] or '', r[5]) for r in queue_values]
assert len(queue_keys) == len(set(queue_keys))
known_sources = {(r[0], r[1]) for r in list(updated['Sources'].values)[1:]}
assert len(known_sources) == updated['Sources'].max_row - 1
for slug in missing:
    for song in packs[slug]['songs']:
        for field in ['artist_statement_source_ids', 'editorial_notes_source_ids']:
            assert all((slug, i) in known_sources for i in song.get(field, []))

report = {
    'date': '2026-10-31', 'input_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'output_sha256': hashlib.sha256(DEST.read_bytes()).hexdigest(),
    'added_artist_slugs': missing,
    'sheets': {s.title: {'original_data_rows': s.max_row - 1, 'added_rows': len(added[s.title]), 'final_data_rows': updated[s.title].max_row - 1} for s in wb},
    'queue_tasks_by_field': dict(Counter(r[5] for r in queue_values)),
    'new_queue_tasks': len(added['Research Queue']),
    'supplied_batch7_queue_rows_preserved': len(supplied_queue),
    'new_source_records': len(added['Sources']),
    'checks': ['ZIP CRC and XML validity', 'All original populated cell XML unchanged', 'All original values/styles/data types unchanged', 'Unrelated package parts unchanged', '53 unique artists / 530 unique per-artist selections', '10 selections per artist', 'No duplicate research tasks or scoped source IDs', 'New source references resolve', 'Table ranges expanded', 'No source strings executed as formulas'],
    'site_modified': False,
}
(OUT / 'worksheet_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
print('OUTPUT', DEST, DEST.stat().st_size)
