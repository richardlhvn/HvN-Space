AFTERGLOW LOCAL UPDATE — Core 0.10.1 / Theme 0.5.1

This updates the existing WordPress Docker project. It includes no credentials,
database backups, uploads, volumes, or dependency directories.

1. Open Ubuntu/WSL in the existing HvN-Space project folder (compose.yaml is there).
   With the current site running, run: bash scripts/backup.sh
   Keep the generated .runtime/backups SQL file private.
2. Extract this update ZIP into a temporary folder. Copy its plugin, theme and
   scripts folders into the EXISTING project folder and allow existing files to
   be replaced. Merge folders; do not delete the existing project or folders.
   Keep .env, compose.yaml, .runtime, uploads and Docker volumes.
3. In Ubuntu/WSL, from that same project folder, run:
   chmod -R a+rX plugin theme scripts
   docker compose restart wordpress
   If services are stopped instead, run: npm start
4. Open your normal local WordPress administration address, usually
   http://localhost:8080/wp-admin/ . Keep your existing login.
5. Artists > Reviewed workbook enrichment: inspect the dry-run summary. If it
   reports conflicts or missing artists, retain everything and send the exact
   message for diagnosis. Do not reset or force overwrite.
   If ready, check "Show new pages on this local/staging site for review
   (noindex)" and click "Apply reviewed enrichment". Existing reviewed records
   are skipped on repeats; later editor changes are protected.
6. Artists > Public catalog > Use ten-artist core catalog.
7. Check the artist directory (10 artists), song directory (128 songs), existing
   song pages and the new Clara Mae / Crash page. Try a Spotify player. A hidden
   profile such as /artists/rosie/ should return 404 for a normal visitor. Rosie
   Darling at /artists/rosie-darling/ remains public. An editor can Preview hidden
   records through WordPress admin.

Your local database is separate from the cloud database. This ZIP does not copy
cloud post IDs or database content. The reviewed importer updates your local
records by stable keys and preserves IDs, URLs, sources and editor changes.
Do not run docker compose down -v or replace .env.

No production deployment or indexing change is included. All 53 artists remain
stored; only the ten core artists / 128 approved songs appear publicly after
step 6. Later, Artists > Public catalog lets you include another reviewed artist
and explicitly selected songs.
